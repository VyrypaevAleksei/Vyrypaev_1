package kz.ncanode.unit.wrapper

import kz.ncanode.common.WithTestData
import org.springframework.boot.test.context.SpringBootTest
import spock.lang.Specification

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.NONE)
class DocumentWrapperTest extends Specification implements WithTestData {

}
