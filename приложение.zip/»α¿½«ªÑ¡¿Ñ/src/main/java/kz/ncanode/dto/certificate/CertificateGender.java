package kz.ncanode.dto.certificate;

public enum CertificateGender {
    NONE,
    MALE,
    FEMALE,
}
